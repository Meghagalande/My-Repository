package com.product;

public class Laptop extends Product{

	
	
}
